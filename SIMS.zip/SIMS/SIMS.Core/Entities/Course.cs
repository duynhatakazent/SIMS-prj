﻿namespace SIMS.Core.Entities
{
    public class Course : BaseEntity
    {
        public string CourseCode { get; set; } = string.Empty;
        public string CourseName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int Credits { get; set; }
        public string Department { get; set; } = string.Empty;
        public int MaxStudents { get; set; }
        public string Semester { get; set; } = string.Empty;
        public int Year { get; set; }
        public string InstructorId { get; set; } = string.Empty;

        // Thêm các thuộc tính mới này
        public string InstructorName { get; set; } = string.Empty;
        public string Schedule { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public string Prerequisites { get; set; } = string.Empty;

        // Navigation properties
        public virtual ICollection<StudentCourse> StudentCourses { get; set; } = new List<StudentCourse>();
    }
}