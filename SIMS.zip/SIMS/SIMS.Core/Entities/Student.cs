﻿namespace SIMS.Core.Entities
{
    public class Student : BaseEntity
    {
        public string StudentCode { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public DateTime DateOfBirth { get; set; }
        public string Address { get; set; } = string.Empty;
        public string Gender { get; set; } = string.Empty;
        public DateTime EnrollmentDate { get; set; }
        public string AcademicProgram { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;

        // Navigation properties
        public virtual ICollection<StudentCourse> StudentCourses { get; set; } = new List<StudentCourse>();
    }
}