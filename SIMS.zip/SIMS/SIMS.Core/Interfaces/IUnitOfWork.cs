﻿using SIMS.Core.Entities;

namespace SIMS.Core.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        IRepository<Student> Students { get; }
        IRepository<Course> Courses { get; }
        IRepository<StudentCourse> StudentCourses { get; }
        Task<int> CommitAsync();
        Task RollbackAsync();
    }
}