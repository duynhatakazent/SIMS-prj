﻿namespace SIMS.Core.Enums
{
    public static class UserRole
    {
        public const string Admin = "Admin";
        public const string Faculty = "Faculty";
        public const string Student = "Student";
    }
}
