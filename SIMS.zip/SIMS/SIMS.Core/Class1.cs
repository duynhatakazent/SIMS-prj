﻿namespace SIMS.Core
{
    public class Class1
    {

    }
}
