﻿using SIMS.Core.Entities;
using SIMS.Core.Interfaces;
using SIMS.Infrastructure.Data;

namespace SIMS.Infrastructure.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationDbContext _context;
        private IRepository<Student>? _students;
        private IRepository<Course>? _courses;
        private IRepository<StudentCourse>? _studentCourses;

        public UnitOfWork(ApplicationDbContext context)
        {
            _context = context;
        }

        public IRepository<Student> Students
        {
            get { return _students ??= new Repository<Student>(_context); }
        }

        public IRepository<Course> Courses
        {
            get { return _courses ??= new Repository<Course>(_context); }
        }

        public IRepository<StudentCourse> StudentCourses
        {
            get { return _studentCourses ??= new Repository<StudentCourse>(_context); }
        }

        public async Task<int> CommitAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public Task RollbackAsync()
        {
            // EF Core doesn't support explicit rollback
            // Changes are automatically rolled back if SaveChanges fails
            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}