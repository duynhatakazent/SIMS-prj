﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SIMS.Core.Entities;

namespace SIMS.Infrastructure.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<StudentCourse> StudentCourses { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Student Configuration
            builder.Entity<Student>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.StudentCode).IsRequired().HasMaxLength(20);
                entity.HasIndex(e => e.StudentCode).IsUnique();
                entity.Property(e => e.Email).IsRequired().HasMaxLength(100);
                entity.HasIndex(e => e.Email).IsUnique();
                entity.Property(e => e.FirstName).IsRequired().HasMaxLength(50);
                entity.Property(e => e.LastName).IsRequired().HasMaxLength(50);
                entity.HasQueryFilter(e => !e.IsDeleted);
            });

            // Course Configuration
            builder.Entity<Course>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.CourseCode).IsRequired().HasMaxLength(20);
                entity.HasIndex(e => e.CourseCode).IsUnique();
                entity.Property(e => e.CourseName).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Credits).IsRequired();
                entity.Property(e => e.Department).HasMaxLength(100);
                entity.Property(e => e.Semester).HasMaxLength(50);
                entity.Property(e => e.InstructorId).HasMaxLength(450);
                entity.Property(e => e.InstructorName).HasMaxLength(200);
                entity.Property(e => e.Schedule).HasMaxLength(200);
                entity.Property(e => e.Location).HasMaxLength(200);
                entity.Property(e => e.Prerequisites).HasMaxLength(500);
                entity.HasQueryFilter(e => !e.IsDeleted);
            });

            // StudentCourse Configuration (Many-to-Many)
            builder.Entity<StudentCourse>(entity =>
            {
                entity.HasKey(e => e.Id);

                entity.HasOne(sc => sc.Student)
                    .WithMany(s => s.StudentCourses)
                    .HasForeignKey(sc => sc.StudentId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(sc => sc.Course)
                    .WithMany(c => c.StudentCourses)
                    .HasForeignKey(sc => sc.CourseId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.Property(sc => sc.Status).HasMaxLength(50);

                // Fix warning: Chỉ định precision và scale cho Grade
                entity.Property(sc => sc.Grade)
                    .HasPrecision(5, 2); // 5 digits total, 2 after decimal (e.g., 100.00)

                entity.Property(sc => sc.EnrollmentDate).IsRequired();

                entity.HasIndex(e => new { e.StudentId, e.CourseId });
                entity.HasQueryFilter(e => !e.IsDeleted);
            });
        }
    }
}