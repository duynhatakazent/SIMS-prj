﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SIMS.Core.Entities;
using SIMS.Core.Enums;

namespace SIMS.Infrastructure.Data
{
    public static class DbInitializer
    {
        public static async Task InitializeAsync(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            RoleManager<IdentityRole> roleManager)
        {
            // Ensure database is created
            await context.Database.MigrateAsync();

            // Seed Roles
            await SeedRolesAsync(roleManager);

            // Seed Admin User
            await SeedAdminAsync(userManager);

            // Seed Sample Data
            await SeedSampleDataAsync(context, userManager);
        }

        private static async Task SeedRolesAsync(RoleManager<IdentityRole> roleManager)
        {
            string[] roles = { UserRole.Admin, UserRole.Faculty, UserRole.Student };

            foreach (var role in roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                {
                    await roleManager.CreateAsync(new IdentityRole(role));
                }
            }
        }

        private static async Task SeedAdminAsync(UserManager<ApplicationUser> userManager)
        {
            var adminEmail = "admin@sims.edu";
            var adminUser = await userManager.FindByEmailAsync(adminEmail);

            if (adminUser == null)
            {
                adminUser = new ApplicationUser
                {
                    UserName = adminEmail,
                    Email = adminEmail,
                    FirstName = "System",
                    LastName = "Administrator",
                    EmailConfirmed = true
                };

                var result = await userManager.CreateAsync(adminUser, "Admin@123");
                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(adminUser, UserRole.Admin);
                }
            }
        }

        private static async Task SeedSampleDataAsync(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            if (!context.Courses.Any())
            {
                var courses = new List<Course>
                {
                    new Course
                    {
                        CourseCode = "CS101",
                        CourseName = "Introduction to Computer Science",
                        Description = "Basic concepts of programming and computer science fundamentals",
                        Credits = 3,
                        Department = "Computer Science",
                        MaxStudents = 50,
                        Semester = "Fall",
                        Year = 2024
                    },
                    new Course
                    {
                        CourseCode = "MATH201",
                        CourseName = "Calculus I",
                        Description = "Differential and integral calculus with applications",
                        Credits = 4,
                        Department = "Mathematics",
                        MaxStudents = 40,
                        Semester = "Fall",
                        Year = 2024
                    },
                    new Course
                    {
                        CourseCode = "ENG101",
                        CourseName = "English Composition",
                        Description = "Academic writing and critical thinking",
                        Credits = 3,
                        Department = "English",
                        MaxStudents = 30,
                        Semester = "Fall",
                        Year = 2024
                    }
                };

                await context.Courses.AddRangeAsync(courses);
                await context.SaveChangesAsync();
            }
        }
    }
}