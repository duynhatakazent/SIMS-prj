﻿namespace SIMS.Infrastructure
{
    public class Class1
    {

    }
}
