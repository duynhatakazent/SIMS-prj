﻿// SIMS.Web/Controllers/CoursesController.cs
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SIMS.Core.Entities;
using SIMS.Services.Interfaces;
using SIMS.Web.Models;
using SIMS.Web.Models.ViewModels;
using System.Diagnostics;

namespace SIMS.Web.Controllers
{
    [Authorize]
    public class CoursesController : Controller
    {
        private readonly ICourseService _courseService;

        public CoursesController(ICourseService courseService)
        {
            _courseService = courseService;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var courses = await _courseService.GetAllCoursesAsync();
            var viewModels = new List<CourseViewModel>();

            foreach (var course in courses)
            {
                var students = await _courseService.GetCourseStudentsAsync(course.Id);
                viewModels.Add(new CourseViewModel
                {
                    Id = course.Id,
                    CourseCode = course.CourseCode,
                    CourseName = course.CourseName,
                    Description = course.Description,
                    Credits = course.Credits,
                    Department = course.Department,
                    MaxStudents = course.MaxStudents,
                    Semester = course.Semester,
                    Year = course.Year,
                    CurrentEnrollment = students.Count()
                });
            }

            return View(viewModels);
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var course = await _courseService.GetCourseByIdAsync(id);
            if (course == null)
            {
                return NotFound();
            }

            var students = await _courseService.GetCourseStudentsAsync(id);

            var viewModel = new CourseDetailsViewModel
            {
                Id = course.Id,
                CourseCode = course.CourseCode,
                CourseName = course.CourseName,
                Description = course.Description,
                Credits = course.Credits,
                Department = course.Department,
                MaxStudents = course.MaxStudents,
                Semester = course.Semester,
                Year = course.Year,
                CurrentEnrollment = students.Count(),
                EnrolledStudents = students.Select(s => new EnrolledStudentViewModel
                {
                    StudentId = s.Id,
                    StudentCode = s.StudentCode,
                    FullName = $"{s.FirstName} {s.LastName}",
                    Email = s.Email,
                    AcademicProgram = s.AcademicProgram,
                    EnrollmentDate = s.EnrollmentDate,
                    Status = "Enrolled"
                }).ToList()
            };

            return View(viewModel);
        }

        [HttpGet]
        [Authorize(Roles = "Admin,Faculty")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Faculty")]
        public async Task<IActionResult> Create(CourseViewModel model)
        {
            if (ModelState.IsValid)
            {
                var course = new Course
                {
                    CourseCode = model.CourseCode,
                    CourseName = model.CourseName,
                    Description = model.Description,
                    Credits = model.Credits,
                    Department = model.Department,
                    MaxStudents = model.MaxStudents,
                    Semester = model.Semester,
                    Year = model.Year
                };

                await _courseService.CreateCourseAsync(course);
                TempData["Success"] = "Course created successfully!";
                return RedirectToAction(nameof(Index));
            }

            return View(model);
        }

        [HttpGet]
        [Authorize(Roles = "Admin,Faculty")]
        public async Task<IActionResult> Edit(int id)
        {
            var course = await _courseService.GetCourseByIdAsync(id);
            if (course == null)
            {
                return NotFound();
            }

            var viewModel = new CourseViewModel
            {
                Id = course.Id,
                CourseCode = course.CourseCode,
                CourseName = course.CourseName,
                Description = course.Description,
                Credits = course.Credits,
                Department = course.Department,
                MaxStudents = course.MaxStudents,
                Semester = course.Semester,
                Year = course.Year
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Faculty")]
        public async Task<IActionResult> Edit(int id, CourseViewModel model)
        {
            if (id != model.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var course = await _courseService.GetCourseByIdAsync(id);
                if (course == null)
                {
                    return NotFound();
                }

                course.CourseCode = model.CourseCode;
                course.CourseName = model.CourseName;
                course.Description = model.Description;
                course.Credits = model.Credits;
                course.Department = model.Department;
                course.MaxStudents = model.MaxStudents;
                course.Semester = model.Semester;
                course.Year = model.Year;

                await _courseService.UpdateCourseAsync(course);
                TempData["Success"] = "Course updated successfully!";
                return RedirectToAction(nameof(Index));
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            await _courseService.DeleteCourseAsync(id);
            TempData["Success"] = "Course deleted successfully!";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Enroll(int courseId, int studentId)
        {
            try
            {
                var result = await _courseService.EnrollStudentAsync(studentId, courseId);
                if (result)
                {
                    TempData["Success"] = "Student enrolled successfully!";
                }
                else
                {
                    TempData["Error"] = "Student is already enrolled in this course.";
                }
            }
            catch (InvalidOperationException ex)
            {
                TempData["Error"] = ex.Message;
            }

            return RedirectToAction(nameof(Details), new { id = courseId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Faculty")]
        public async Task<IActionResult> Unenroll(int courseId, int studentId)
        {
            var result = await _courseService.UnenrollStudentAsync(studentId, courseId);
            if (result)
            {
                TempData["Success"] = "Student unenrolled successfully!";
            }
            else
            {
                TempData["Error"] = "Failed to unenroll student.";
            }

            return RedirectToAction(nameof(Details), new { id = courseId });
        }
    }
}
