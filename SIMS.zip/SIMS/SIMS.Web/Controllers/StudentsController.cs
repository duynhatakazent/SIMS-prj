﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using SIMS.Core.Entities;
using SIMS.Services.Interfaces;
using SIMS.Web.Models.ViewModels;

namespace SIMS.Web.Controllers
{
    [Authorize]
    public class StudentsController : Controller
    {
        private readonly IStudentService _studentService;
        private readonly ICourseService _courseService;

        public StudentsController(IStudentService studentService, ICourseService courseService)
        {
            _studentService = studentService;
            _courseService = courseService;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var students = await _studentService.GetAllStudentsAsync();
            var viewModels = students.Select(s => new StudentViewModel
            {
                Id = s.Id,
                StudentCode = s.StudentCode,
                FirstName = s.FirstName,
                LastName = s.LastName,
                Email = s.Email,
                PhoneNumber = s.PhoneNumber,
                DateOfBirth = s.DateOfBirth,
                Address = s.Address,
                Gender = s.Gender,
                EnrollmentDate = s.EnrollmentDate,
                AcademicProgram = s.AcademicProgram
            }).ToList();

            return View(viewModels);
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var student = await _studentService.GetStudentByIdAsync(id);
            if (student == null)
            {
                return NotFound();
            }

            var courses = await _studentService.GetStudentCoursesAsync(id);

            ViewBag.Courses = courses;

            var viewModel = new StudentViewModel
            {
                Id = student.Id,
                StudentCode = student.StudentCode,
                FirstName = student.FirstName,
                LastName = student.LastName,
                Email = student.Email,
                PhoneNumber = student.PhoneNumber,
                DateOfBirth = student.DateOfBirth,
                Address = student.Address,
                Gender = student.Gender,
                EnrollmentDate = student.EnrollmentDate,
                AcademicProgram = student.AcademicProgram
            };

            return View(viewModel);
        }

        [HttpGet]
        [Authorize(Roles = "Admin,Faculty")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Faculty")]
        public async Task<IActionResult> Create(StudentViewModel model)
        {
            if (ModelState.IsValid)
            {
                var student = new Student
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    PhoneNumber = model.PhoneNumber,
                    DateOfBirth = model.DateOfBirth,
                    Address = model.Address,
                    Gender = model.Gender,
                    AcademicProgram = model.AcademicProgram
                };

                await _studentService.CreateStudentAsync(student);
                TempData["Success"] = "Student created successfully!";
                return RedirectToAction(nameof(Index));
            }

            return View(model);
        }

        [HttpGet]
        [Authorize(Roles = "Admin,Faculty")]
        public async Task<IActionResult> Edit(int id)
        {
            var student = await _studentService.GetStudentByIdAsync(id);
            if (student == null)
            {
                return NotFound();
            }

            var viewModel = new StudentViewModel
            {
                Id = student.Id,
                StudentCode = student.StudentCode,
                FirstName = student.FirstName,
                LastName = student.LastName,
                Email = student.Email,
                PhoneNumber = student.PhoneNumber,
                DateOfBirth = student.DateOfBirth,
                Address = student.Address,
                Gender = student.Gender,
                EnrollmentDate = student.EnrollmentDate,
                AcademicProgram = student.AcademicProgram
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Faculty")]
        public async Task<IActionResult> Edit(int id, StudentViewModel model)
        {
            if (id != model.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var student = await _studentService.GetStudentByIdAsync(id);
                if (student == null)
                {
                    return NotFound();
                }

                student.FirstName = model.FirstName;
                student.LastName = model.LastName;
                student.Email = model.Email;
                student.PhoneNumber = model.PhoneNumber;
                student.DateOfBirth = model.DateOfBirth;
                student.Address = model.Address;
                student.Gender = model.Gender;
                student.AcademicProgram = model.AcademicProgram;

                await _studentService.UpdateStudentAsync(student);
                TempData["Success"] = "Student updated successfully!";
                return RedirectToAction(nameof(Index));
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            await _studentService.DeleteStudentAsync(id);
            TempData["Success"] = "Student deleted successfully!";
            return RedirectToAction(nameof(Index));
        }
    }
}