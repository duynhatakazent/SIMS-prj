﻿// SIMS.Web/Models/ViewModels/CourseDetailsViewModel.cs
using System.ComponentModel.DataAnnotations;

namespace SIMS.Web.Models.ViewModels
{
    public class CourseDetailsViewModel
    {
        public int Id { get; set; }

        [Display(Name = "Course Code")]
        public string CourseCode { get; set; } = string.Empty;

        [Display(Name = "Course Name")]
        public string CourseName { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        public int Credits { get; set; }

        public string Department { get; set; } = string.Empty;

        [Display(Name = "Maximum Students")]
        public int MaxStudents { get; set; }

        public string Semester { get; set; } = string.Empty;

        public int Year { get; set; }

        [Display(Name = "Current Enrollment")]
        public int CurrentEnrollment { get; set; }

        [Display(Name = "Available Spots")]
        public int AvailableSpots => MaxStudents - CurrentEnrollment;

        [Display(Name = "Is Full")]
        public bool IsFull => CurrentEnrollment >= MaxStudents;

        [Display(Name = "Enrollment Percentage")]
        public double EnrollmentPercentage => MaxStudents > 0 ? (double)CurrentEnrollment / MaxStudents * 100 : 0;

        // Navigation properties
        public List<EnrolledStudentViewModel> EnrolledStudents { get; set; } = new List<EnrolledStudentViewModel>();
    }

    public class EnrolledStudentViewModel
    {
        public int StudentId { get; set; }

        [Display(Name = "Student Code")]
        public string StudentCode { get; set; } = string.Empty;

        [Display(Name = "Full Name")]
        public string FullName { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        [Display(Name = "Academic Program")]
        public string AcademicProgram { get; set; } = string.Empty;

        [Display(Name = "Enrollment Date")]
        public DateTime EnrollmentDate { get; set; }

        public string Status { get; set; } = string.Empty;

        public decimal? Grade { get; set; }
    }
}