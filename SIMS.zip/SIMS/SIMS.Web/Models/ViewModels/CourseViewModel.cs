﻿using System.ComponentModel.DataAnnotations;

namespace SIMS.Web.Models.ViewModels
{
    public class CourseViewModel
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Course Code")]
        public string CourseCode { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Course Name")]
        public string CourseName { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        [Required]
        [Range(1, 6)]
        public int Credits { get; set; }

        public string Department { get; set; } = string.Empty;

        [Display(Name = "Maximum Students")]
        [Range(1, 200)]
        public int MaxStudents { get; set; }

        public string Semester { get; set; } = string.Empty;

        [Range(2020, 2100)]
        public int Year { get; set; }

        [Display(Name = "Current Enrollment")]
        public int CurrentEnrollment { get; set; }

        [Display(Name = "Available Spots")]
        public int AvailableSpots => MaxStudents - CurrentEnrollment;

        [Display(Name = "Is Full")]
        public bool IsFull => CurrentEnrollment >= MaxStudents;
    }
}