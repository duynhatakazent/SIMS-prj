﻿// SIMS.Web/Models/ViewModels/StudentDetailsViewModel.cs
using System.ComponentModel.DataAnnotations;

namespace SIMS.Web.Models.ViewModels
{
    public class StudentDetailsViewModel
    {
        public int Id { get; set; }

        [Display(Name = "Student Code")]
        public string StudentCode { get; set; } = string.Empty;

        [Display(Name = "First Name")]
        public string FirstName { get; set; } = string.Empty;

        [Display(Name = "Last Name")]
        public string LastName { get; set; } = string.Empty;

        [Display(Name = "Full Name")]
        public string FullName => $"{FirstName} {LastName}";

        public string Email { get; set; } = string.Empty;

        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; } = string.Empty;

        [Display(Name = "Date of Birth")]
        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }

        [Display(Name = "Age")]
        public int Age => DateTime.Now.Year - DateOfBirth.Year;

        public string Address { get; set; } = string.Empty;

        public string Gender { get; set; } = string.Empty;

        [Display(Name = "Enrollment Date")]
        public DateTime EnrollmentDate { get; set; }

        [Display(Name = "Academic Program")]
        public string AcademicProgram { get; set; } = string.Empty;

        [Display(Name = "Total Credits Enrolled")]
        public int TotalCredits { get; set; }

        // Navigation properties
        public List<EnrolledCourseViewModel> EnrolledCourses { get; set; } = new List<EnrolledCourseViewModel>();
    }

    public class EnrolledCourseViewModel
    {
        public int CourseId { get; set; }

        [Display(Name = "Course Code")]
        public string CourseCode { get; set; } = string.Empty;

        [Display(Name = "Course Name")]
        public string CourseName { get; set; } = string.Empty;

        public int Credits { get; set; }

        public string Department { get; set; } = string.Empty;

        public string Semester { get; set; } = string.Empty;

        public int Year { get; set; }

        [Display(Name = "Semester/Year")]
        public string SemesterYear => $"{Semester} {Year}";

        [Display(Name = "Enrollment Date")]
        public DateTime EnrollmentDate { get; set; }

        public string Status { get; set; } = string.Empty;

        public decimal? Grade { get; set; }
    }
}