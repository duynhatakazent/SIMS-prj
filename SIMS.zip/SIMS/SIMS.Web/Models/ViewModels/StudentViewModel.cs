﻿using System.ComponentModel.DataAnnotations;

namespace SIMS.Web.Models.ViewModels
{
    public class StudentViewModel
    {
        public int Id { get; set; }

        [Display(Name = "Student Code")]
        public string StudentCode { get; set; } = string.Empty;

        [Required]
        [Display(Name = "First Name")]
        public string FirstName { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Date of Birth")]
        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }

        public string Address { get; set; } = string.Empty;

        public string Gender { get; set; } = string.Empty;

        [Display(Name = "Enrollment Date")]
        public DateTime EnrollmentDate { get; set; }

        [Display(Name = "Academic Program")]
        public string AcademicProgram { get; set; } = string.Empty;
    }
}