﻿namespace SIMS.Services
{
    public class Class1
    {

    }
}
