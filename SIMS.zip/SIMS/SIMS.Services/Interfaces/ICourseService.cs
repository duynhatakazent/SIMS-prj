﻿// SIMS.Services/Interfaces/ICourseService.cs
using SIMS.Core.Entities;

namespace SIMS.Services.Interfaces
{
    public interface ICourseService
    {
        Task<Course> CreateCourseAsync(Course course);
        Task<Course?> GetCourseByIdAsync(int id);
        Task<Course?> GetCourseByCodeAsync(string courseCode);
        Task<IEnumerable<Course>> GetAllCoursesAsync();
        Task UpdateCourseAsync(Course course);
        Task DeleteCourseAsync(int id);
        Task<bool> CourseExistsAsync(string courseCode);
        Task<IEnumerable<Student>> GetCourseStudentsAsync(int courseId);
        Task<bool> EnrollStudentAsync(int studentId, int courseId);
        Task<bool> UnenrollStudentAsync(int studentId, int courseId);
    }
}