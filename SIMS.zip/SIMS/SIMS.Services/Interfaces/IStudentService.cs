﻿// SIMS.Services/Interfaces/IStudentService.cs
using SIMS.Core.Entities;

namespace SIMS.Services.Interfaces
{
    public interface IStudentService
    {
        Task<Student> CreateStudentAsync(Student student);
        Task<Student?> GetStudentByIdAsync(int id);
        Task<Student?> GetStudentByCodeAsync(string studentCode);
        Task<IEnumerable<Student>> GetAllStudentsAsync();
        Task UpdateStudentAsync(Student student);
        Task DeleteStudentAsync(int id);
        Task<bool> StudentExistsAsync(string email);
        Task<IEnumerable<Course>> GetStudentCoursesAsync(int studentId);
    }
}