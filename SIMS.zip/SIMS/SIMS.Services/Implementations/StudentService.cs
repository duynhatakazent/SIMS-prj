﻿// SIMS.Services/Implementations/StudentService.cs
using Microsoft.EntityFrameworkCore;
using SIMS.Core.Entities;
using SIMS.Core.Interfaces;
using SIMS.Services.Interfaces;

namespace SIMS.Services.Implementations
{
    public class StudentService : IStudentService
    {
        private readonly IUnitOfWork _unitOfWork;

        public StudentService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<Student> CreateStudentAsync(Student student)
        {
            if (await StudentExistsAsync(student.Email))
            {
                throw new InvalidOperationException("Student with this email already exists");
            }

            student.StudentCode = await GenerateStudentCodeAsync();
            student.EnrollmentDate = DateTime.UtcNow;

            await _unitOfWork.Students.AddAsync(student);
            await _unitOfWork.CommitAsync();

            return student;
        }

        public async Task<Student?> GetStudentByIdAsync(int id)
        {
            return await _unitOfWork.Students.GetByIdAsync(id);
        }

        public async Task<Student?> GetStudentByCodeAsync(string studentCode)
        {
            var students = await _unitOfWork.Students.FindAsync(s => s.StudentCode == studentCode);
            return students.FirstOrDefault();
        }

        public async Task<IEnumerable<Student>> GetAllStudentsAsync()
        {
            return await _unitOfWork.Students.GetAllAsync();
        }

        public async Task UpdateStudentAsync(Student student)
        {
            student.UpdatedAt = DateTime.UtcNow;
            await _unitOfWork.Students.UpdateAsync(student);
            await _unitOfWork.CommitAsync();
        }

        public async Task DeleteStudentAsync(int id)
        {
            var student = await _unitOfWork.Students.GetByIdAsync(id);
            if (student != null)
            {
                student.IsDeleted = true;
                student.UpdatedAt = DateTime.UtcNow;
                await _unitOfWork.Students.UpdateAsync(student);
                await _unitOfWork.CommitAsync();
            }
        }

        public async Task<bool> StudentExistsAsync(string email)
        {
            return await _unitOfWork.Students.ExistsAsync(s => s.Email == email);
        }

        public async Task<IEnumerable<Course>> GetStudentCoursesAsync(int studentId)
        {
            var enrollments = await _unitOfWork.StudentCourses
                .FindAsync(sc => sc.StudentId == studentId);

            var courseIds = enrollments.Select(e => e.CourseId).ToList();
            var courses = await _unitOfWork.Courses
                .FindAsync(c => courseIds.Contains(c.Id));

            return courses;
        }

        private async Task<string> GenerateStudentCodeAsync()
        {
            var year = DateTime.Now.Year.ToString();
            var count = await _unitOfWork.Students.CountAsync(s => s.StudentCode.StartsWith(year));
            return $"{year}{(count + 1):D6}";
        }
    }
}