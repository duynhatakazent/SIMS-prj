﻿// SIMS.Services/Implementations/CourseService.cs
using SIMS.Core.Entities;
using SIMS.Core.Interfaces;
using SIMS.Services.Interfaces;

namespace SIMS.Services.Implementations
{
    public class CourseService : ICourseService
    {
        private readonly IUnitOfWork _unitOfWork;

        public CourseService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<Course> CreateCourseAsync(Course course)
        {
            if (await CourseExistsAsync(course.CourseCode))
            {
                throw new InvalidOperationException("Course with this code already exists");
            }

            await _unitOfWork.Courses.AddAsync(course);
            await _unitOfWork.CommitAsync();

            return course;
        }

        public async Task<Course?> GetCourseByIdAsync(int id)
        {
            return await _unitOfWork.Courses.GetByIdAsync(id);
        }

        public async Task<Course?> GetCourseByCodeAsync(string courseCode)
        {
            var courses = await _unitOfWork.Courses.FindAsync(c => c.CourseCode == courseCode);
            return courses.FirstOrDefault();
        }

        public async Task<IEnumerable<Course>> GetAllCoursesAsync()
        {
            return await _unitOfWork.Courses.GetAllAsync();
        }

        public async Task UpdateCourseAsync(Course course)
        {
            course.UpdatedAt = DateTime.UtcNow;
            await _unitOfWork.Courses.UpdateAsync(course);
            await _unitOfWork.CommitAsync();
        }

        public async Task DeleteCourseAsync(int id)
        {
            var course = await _unitOfWork.Courses.GetByIdAsync(id);
            if (course != null)
            {
                course.IsDeleted = true;
                course.UpdatedAt = DateTime.UtcNow;
                await _unitOfWork.Courses.UpdateAsync(course);
                await _unitOfWork.CommitAsync();
            }
        }

        public async Task<bool> CourseExistsAsync(string courseCode)
        {
            return await _unitOfWork.Courses.ExistsAsync(c => c.CourseCode == courseCode);
        }

        public async Task<IEnumerable<Student>> GetCourseStudentsAsync(int courseId)
        {
            var enrollments = await _unitOfWork.StudentCourses
                .FindAsync(sc => sc.CourseId == courseId);

            var studentIds = enrollments.Select(e => e.StudentId).ToList();
            var students = await _unitOfWork.Students
                .FindAsync(s => studentIds.Contains(s.Id));

            return students;
        }

        public async Task<bool> EnrollStudentAsync(int studentId, int courseId)
        {
            var student = await _unitOfWork.Students.GetByIdAsync(studentId);
            var course = await _unitOfWork.Courses.GetByIdAsync(courseId);

            if (student == null || course == null)
                return false;

            var exists = await _unitOfWork.StudentCourses
                .ExistsAsync(sc => sc.StudentId == studentId && sc.CourseId == courseId);

            if (exists)
                return false;

            var currentEnrollment = await _unitOfWork.StudentCourses
                .CountAsync(sc => sc.CourseId == courseId);

            if (currentEnrollment >= course.MaxStudents)
                throw new InvalidOperationException("Course is full");

            var enrollment = new StudentCourse
            {
                StudentId = studentId,
                CourseId = courseId,
                EnrollmentDate = DateTime.UtcNow,
                Status = "Enrolled"
            };

            await _unitOfWork.StudentCourses.AddAsync(enrollment);
            await _unitOfWork.CommitAsync();

            return true;
        }

        public async Task<bool> UnenrollStudentAsync(int studentId, int courseId)
        {
            var enrollments = await _unitOfWork.StudentCourses
                .FindAsync(sc => sc.StudentId == studentId && sc.CourseId == courseId);

            var enrollment = enrollments.FirstOrDefault();
            if (enrollment == null)
                return false;

            enrollment.IsDeleted = true;
            enrollment.UpdatedAt = DateTime.UtcNow;
            await _unitOfWork.StudentCourses.UpdateAsync(enrollment);
            await _unitOfWork.CommitAsync();

            return true;
        }
    }
}